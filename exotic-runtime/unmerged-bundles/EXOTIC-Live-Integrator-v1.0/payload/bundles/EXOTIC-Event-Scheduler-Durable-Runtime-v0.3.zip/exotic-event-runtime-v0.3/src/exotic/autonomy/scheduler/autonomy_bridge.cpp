#include "autonomy_bridge.hpp"

namespace exotic::autonomy::scheduler {
AutonomyExecutionBridge::AutonomyExecutionBridge(AutonomyKernel& k,std::string a):kernel_(k),agent_id_(std::move(a)){}
ExecutionResult AutonomyExecutionBridge::execute(const Job& job,std::stop_token stop){
    if(stop.stop_requested()) return {false,FailureClass::Cancelled,"shutdown requested"};
    auto decision=kernel_.evaluate_proposal(job.proposal_id);
    if(decision.decision==DecisionType::Deny) return {false,FailureClass::PolicyDenied,decision.reason};
    if(decision.decision!=DecisionType::Approve) return {false,FailureClass::Transient,decision.reason};
    auto operation=kernel_.execute_proposal(job.proposal_id,agent_id_);
    if(!operation) return {false,FailureClass::Transient,"proposal could not start"};
    if(stop.stop_requested()) { kernel_.cancel_operation(*operation); return {false,FailureClass::Cancelled,"shutdown requested"}; }
    auto verification=kernel_.verify_operation(*operation);
    if(!verification.passed) return {false,FailureClass::VerificationFailed,"operation failed verification"};
    return {true,FailureClass::Permanent,"verified"};
}
} // namespace exotic::autonomy::scheduler
