#pragma once
#include "execution_bridge.hpp"
#include "../autonomy_kernel.hpp"

namespace exotic::autonomy::scheduler {

class AutonomyExecutionBridge final : public ExecutionBridge {
public:
    AutonomyExecutionBridge(AutonomyKernel& kernel, std::string agent_id);
    ExecutionResult execute(const Job& job, std::stop_token stop_token) override;
private:
    AutonomyKernel& kernel_;
    std::string agent_id_;
};

} // namespace exotic::autonomy::scheduler
