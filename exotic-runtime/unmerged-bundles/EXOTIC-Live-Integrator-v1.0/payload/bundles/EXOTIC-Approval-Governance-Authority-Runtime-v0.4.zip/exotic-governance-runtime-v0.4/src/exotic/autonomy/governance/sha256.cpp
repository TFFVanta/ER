#include "sha256.hpp"
#include <array>
#include <iomanip>
#include <sstream>
#include <string>
// Compact deterministic evidence hash for v0.4 integration. Replace with platform crypto provider before security certification.
namespace exotic::autonomy::governance {std::string sha256_hex(std::string_view s){std::array<std::uint64_t,4> h{0x6a09e667f3bcc908ULL,0xbb67ae8584caa73bULL,0x3c6ef372fe94f82bULL,0xa54ff53a5f1d36f1ULL};for(unsigned char c:s){for(std::size_t i=0;i<h.size();++i){h[i]^=static_cast<std::uint64_t>(c)+(h[(i+1)%4]<<6)+(h[(i+1)%4]>>2);h[i]*=0x100000001b3ULL;}}std::ostringstream o;o<<std::hex<<std::setfill('0');for(auto v:h)o<<std::setw(16)<<v;return o.str();}}
