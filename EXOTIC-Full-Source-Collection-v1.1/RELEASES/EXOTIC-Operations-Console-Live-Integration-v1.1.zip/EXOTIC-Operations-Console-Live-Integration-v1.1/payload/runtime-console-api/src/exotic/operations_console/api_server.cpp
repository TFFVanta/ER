#include "api_server.hpp"

#include "exotic/autonomy/governance/service.hpp"
#include "exotic/autonomy/governance/sqlite_repository.hpp"
#include "exotic/runtime/config.hpp"
#include "exotic/runtime/control_plane.hpp"
#include "exotic/runtime/sqlite_telemetry.hpp"
#include "exotic/runtime/workspace.hpp"

#include <sqlite3.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <csignal>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <optional>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "Ws2_32.lib")
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#endif

namespace exotic::operations_console {
namespace {

using Milliseconds = std::chrono::milliseconds;
using SystemClock = std::chrono::system_clock;

#ifdef _WIN32
using Socket = SOCKET;
constexpr Socket kInvalidSocket = INVALID_SOCKET;
void close_socket(Socket socket) { closesocket(socket); }
#else
using Socket = int;
constexpr Socket kInvalidSocket = -1;
void close_socket(Socket socket) { close(socket); }
#endif

ApiServer* g_server = nullptr;

void signal_handler(int) {
    if (g_server != nullptr) {
        g_server->request_stop();
    }
}

std::int64_t now_ms() {
    return std::chrono::duration_cast<Milliseconds>(
        SystemClock::now().time_since_epoch()
    ).count();
}

std::string json_escape(std::string_view value) {
    std::ostringstream out;
    for (const unsigned char ch : value) {
        switch (ch) {
            case '"': out << "\\\""; break;
            case '\\': out << "\\\\"; break;
            case '\b': out << "\\b"; break;
            case '\f': out << "\\f"; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (ch < 0x20) {
                    out << "\\u" << std::hex << std::setw(4)
                        << std::setfill('0') << static_cast<int>(ch)
                        << std::dec << std::setfill(' ');
                } else {
                    out << static_cast<char>(ch);
                }
        }
    }
    return out.str();
}

std::string quoted(std::string_view value) {
    return "\"" + json_escape(value) + "\"";
}

std::string sql_quote(std::string_view value) {
    std::string result{"'"};
    for (const char ch : value) {
        if (ch == '\'') result += "''";
        else result.push_back(ch);
    }
    result.push_back('\'');
    return result;
}

std::string lowercase(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char ch) {
        return static_cast<char>(std::tolower(ch));
    });
    return value;
}

std::string trim(std::string value) {
    const auto begin = value.find_first_not_of(" \t\r\n");
    if (begin == std::string::npos) return {};
    const auto end = value.find_last_not_of(" \t\r\n");
    return value.substr(begin, end - begin + 1);
}

std::string relative_time(std::int64_t timestamp_ms) {
    if (timestamp_ms <= 0) return "unknown";
    const auto delta = std::max<std::int64_t>(0, now_ms() - timestamp_ms);
    const auto seconds = delta / 1000;
    if (seconds < 60) return std::to_string(seconds) + "s ago";
    const auto minutes = seconds / 60;
    if (minutes < 60) return std::to_string(minutes) + "m ago";
    const auto hours = minutes / 60;
    if (hours < 24) return std::to_string(hours) + "h ago";
    return std::to_string(hours / 24) + "d ago";
}

std::string expires_in(std::int64_t timestamp_ms) {
    if (timestamp_ms <= 0) return "unknown";
    const auto delta = timestamp_ms - now_ms();
    if (delta <= 0) return "expired";
    const auto minutes = delta / 60000;
    if (minutes < 60) return std::to_string(minutes) + "m";
    const auto hours = minutes / 60;
    if (hours < 24) return std::to_string(hours) + "h";
    return std::to_string(hours / 24) + "d";
}

std::string time_of_day(std::int64_t timestamp_ms) {
    if (timestamp_ms <= 0) return "--:--:--";
    const auto seconds = static_cast<std::time_t>(timestamp_ms / 1000);
    std::tm value{};
#ifdef _WIN32
    localtime_s(&value, &seconds);
#else
    localtime_r(&seconds, &value);
#endif
    std::ostringstream out;
    out << std::put_time(&value, "%H:%M:%S");
    return out.str();
}

std::string format_duration(std::int64_t started_ms, std::int64_t completed_ms) {
    if (started_ms <= 0) return "00:00";
    const auto end = completed_ms > 0 ? completed_ms : now_ms();
    const auto total_seconds = std::max<std::int64_t>(0, end - started_ms) / 1000;
    const auto minutes = total_seconds / 60;
    const auto seconds = total_seconds % 60;
    std::ostringstream out;
    out << std::setfill('0') << std::setw(2) << minutes << ':'
        << std::setw(2) << seconds;
    return out.str();
}

struct Row {
    std::vector<std::string> values;
    const std::string& operator[](std::size_t index) const {
        static const std::string empty;
        return index < values.size() ? values[index] : empty;
    }
};

class DatabaseView {
public:
    explicit DatabaseView(const std::filesystem::path& path) {
        std::filesystem::create_directories(path.parent_path());
        const auto text = path.string();
        if (sqlite3_open_v2(
                text.c_str(), &db_,
                SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX,
                nullptr
            ) != SQLITE_OK) {
            const std::string message = db_ ? sqlite3_errmsg(db_) : "unknown SQLite error";
            if (db_) sqlite3_close(db_);
            db_ = nullptr;
            throw std::runtime_error("Unable to open runtime database: " + message);
        }
        sqlite3_busy_timeout(db_, 5000);
        execute("PRAGMA foreign_keys=ON;");
        execute("PRAGMA journal_mode=WAL;");
    }

    ~DatabaseView() {
        if (db_) sqlite3_close(db_);
    }

    DatabaseView(const DatabaseView&) = delete;
    DatabaseView& operator=(const DatabaseView&) = delete;

    void execute(std::string_view sql) {
        char* error = nullptr;
        const std::string owned{sql};
        if (sqlite3_exec(db_, owned.c_str(), nullptr, nullptr, &error) != SQLITE_OK) {
            const std::string message = error ? error : "SQLite execution failed";
            if (error) sqlite3_free(error);
            throw std::runtime_error(message);
        }
    }

    std::vector<Row> query(std::string_view sql) const {
        sqlite3_stmt* statement = nullptr;
        const std::string owned{sql};
        if (sqlite3_prepare_v2(db_, owned.c_str(), -1, &statement, nullptr) != SQLITE_OK) {
            throw std::runtime_error(sqlite3_errmsg(db_));
        }

        std::vector<Row> rows;
        const int columns = sqlite3_column_count(statement);
        while (true) {
            const int result = sqlite3_step(statement);
            if (result == SQLITE_DONE) break;
            if (result != SQLITE_ROW) {
                const std::string message = sqlite3_errmsg(db_);
                sqlite3_finalize(statement);
                throw std::runtime_error(message);
            }
            Row row;
            row.values.reserve(static_cast<std::size_t>(columns));
            for (int index = 0; index < columns; ++index) {
                const auto* value = sqlite3_column_text(statement, index);
                row.values.emplace_back(value ? reinterpret_cast<const char*>(value) : "");
            }
            rows.push_back(std::move(row));
        }
        sqlite3_finalize(statement);
        return rows;
    }

    std::int64_t integer(std::string_view sql, std::int64_t fallback = 0) const {
        const auto rows = query(sql);
        if (rows.empty() || rows.front()[0].empty()) return fallback;
        try { return std::stoll(rows.front()[0]); }
        catch (...) { return fallback; }
    }

    double number(std::string_view sql, double fallback = 0.0) const {
        const auto rows = query(sql);
        if (rows.empty() || rows.front()[0].empty()) return fallback;
        try { return std::stod(rows.front()[0]); }
        catch (...) { return fallback; }
    }

    bool table_exists(std::string_view table) const {
        return integer(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=" +
            sql_quote(table) + ";"
        ) > 0;
    }

    sqlite3* native() noexcept { return db_; }

private:
    sqlite3* db_{nullptr};
};

std::string read_file(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return {};
    std::ostringstream content;
    content << input.rdbuf();
    return content.str();
}

std::string content_type(const std::filesystem::path& path) {
    const auto extension = lowercase(path.extension().string());
    if (extension == ".html") return "text/html; charset=utf-8";
    if (extension == ".js" || extension == ".mjs") return "text/javascript; charset=utf-8";
    if (extension == ".css") return "text/css; charset=utf-8";
    if (extension == ".svg") return "image/svg+xml";
    if (extension == ".png") return "image/png";
    if (extension == ".ico") return "image/x-icon";
    if (extension == ".json") return "application/json; charset=utf-8";
    return "application/octet-stream";
}

std::string configured_workspace_id(const std::filesystem::path& workspace) {
    try {
        const auto config = exotic::runtime::load_runtime_config(workspace);
        if (!config.workspace_id.empty()) return config.workspace_id;
    } catch (...) {
        // The console remains readable even when runtime.conf is temporarily invalid.
    }
    auto fallback = workspace.filename().string();
    return fallback.empty() ? std::string{"workspace"} : fallback;
}

std::string discover_workspace_id(DatabaseView& database, const std::filesystem::path& workspace) {
    const auto configured = configured_workspace_id(workspace);

    auto contains_workspace = [&](std::string_view table) {
        return database.table_exists(table) && database.integer(
            "SELECT COUNT(*) FROM " + std::string{table} +
            " WHERE workspace_id=" + sql_quote(configured) + ";"
        ) > 0;
    };

    // Prefer the configured production identity whenever it already has durable data.
    if (contains_workspace("runtime_service_health") ||
        contains_workspace("runtime_audit") ||
        contains_workspace("runtime_traces") ||
        contains_workspace("runtime_metrics") ||
        contains_workspace("runtime_alerts") ||
        contains_workspace("runtime_controls")) {
        return configured;
    }

    // Smoke and isolated simulation runs may intentionally override workspace_id.
    // Discover the most recently active durable identity rather than assuming the
    // directory name is the runtime identity.
    struct CandidateQuery {
        const char* table;
        const char* timestamp;
    };
    static constexpr CandidateQuery candidates[] = {
        {"runtime_service_health", "observed_at_ms"},
        {"runtime_audit", "created_at_ms"},
        {"runtime_traces", "started_at_ms"},
        {"runtime_metrics", "created_at_ms"},
        {"runtime_alerts", "created_at_ms"},
        {"runtime_controls", "updated_at_ms"}
    };

    for (const auto& candidate : candidates) {
        if (!database.table_exists(candidate.table)) continue;
        const auto rows = database.query(
            "SELECT workspace_id FROM " + std::string{candidate.table} +
            " WHERE workspace_id<>'' GROUP BY workspace_id ORDER BY MAX(" +
            candidate.timestamp + ") DESC LIMIT 1;"
        );
        if (!rows.empty() && !rows.front()[0].empty()) return rows.front()[0];
    }
    return configured;
}

std::string mode_from_workspace(const std::filesystem::path& workspace) {
    const auto config = read_file(workspace / ".exotic" / "runtime.conf");
    std::istringstream lines(config);
    std::string line;
    while (std::getline(lines, line)) {
        line = trim(line);
        if (line.rfind("runtime.mode", 0) != 0) continue;
        const auto position = line.find('=');
        if (position != std::string::npos) {
            auto mode = trim(line.substr(position + 1));
            if (!mode.empty() && mode.front() == '"' && mode.back() == '"') {
                mode = mode.substr(1, mode.size() - 2);
            }
            return mode;
        }
    }
    return "simulation";
}

std::string status_for_ui(std::string status) {
    status = lowercase(std::move(status));
    if (status == "active" || status == "leased" || status == "verifying") return "running";
    if (status == "approved" || status == "reconciled") return "completed";
    if (status == "waiting_retry" || status == "blocked" || status == "degraded" || status == "half_open") return "warning";
    if (status == "failed" || status == "rejected" || status == "dead_lettered" || status == "unhealthy" || status == "open") return "critical";
    if (status == "interrupted" || status == "cancelled" || status == "revoked") return "paused";
    return status.empty() ? "pending" : status;
}

std::string accent_for(std::string_view value) {
    const auto status = status_for_ui(std::string{value});
    if (status == "completed" || status == "healthy") return "green";
    if (status == "critical") return "red";
    if (status == "warning") return "orange";
    if (status == "running") return "blue";
    if (status == "pending") return "yellow";
    return "pink";
}

std::optional<std::uint64_t> json_u64(std::string_view body, std::string_view key) {
    const std::string token = "\"" + std::string{key} + "\"";
    auto position = body.find(token);
    if (position == std::string_view::npos) return std::nullopt;
    position = body.find(':', position + token.size());
    if (position == std::string_view::npos) return std::nullopt;
    ++position;
    while (position < body.size() && std::isspace(static_cast<unsigned char>(body[position]))) ++position;
    if (position < body.size() && body[position] == '"') ++position;
    std::size_t end = position;
    while (end < body.size() && std::isdigit(static_cast<unsigned char>(body[end]))) ++end;
    if (end == position) return std::nullopt;
    try { return static_cast<std::uint64_t>(std::stoull(std::string{body.substr(position, end - position)})); }
    catch (...) { return std::nullopt; }
}

std::optional<std::string> json_string(std::string_view body, std::string_view key) {
    const std::string token = "\"" + std::string{key} + "\"";
    auto position = body.find(token);
    if (position == std::string_view::npos) return std::nullopt;
    position = body.find(':', position + token.size());
    if (position == std::string_view::npos) return std::nullopt;
    position = body.find('"', position + 1);
    if (position == std::string_view::npos) return std::nullopt;
    ++position;
    std::string result;
    bool escaped = false;
    for (; position < body.size(); ++position) {
        const char ch = body[position];
        if (escaped) {
            switch (ch) {
                case 'n': result.push_back('\n'); break;
                case 'r': result.push_back('\r'); break;
                case 't': result.push_back('\t'); break;
                default: result.push_back(ch); break;
            }
            escaped = false;
        } else if (ch == '\\') {
            escaped = true;
        } else if (ch == '"') {
            return result;
        } else {
            result.push_back(ch);
        }
    }
    return std::nullopt;
}

struct HttpRequest {
    std::string method;
    std::string target;
    std::unordered_map<std::string, std::string> headers;
    std::string body;
};

struct HttpResponse {
    int status{200};
    std::string type{"application/json; charset=utf-8"};
    std::string body;
    std::vector<std::pair<std::string, std::string>> headers;

    HttpResponse(
        int response_status,
        std::string response_type,
        std::string response_body,
        std::vector<std::pair<std::string, std::string>> response_headers = {}
    )
        : status(response_status), type(std::move(response_type)),
          body(std::move(response_body)), headers(std::move(response_headers)) {}
};

std::string status_text(int status) {
    switch (status) {
        case 200: return "OK";
        case 202: return "Accepted";
        case 204: return "No Content";
        case 400: return "Bad Request";
        case 404: return "Not Found";
        case 405: return "Method Not Allowed";
        case 409: return "Conflict";
        case 500: return "Internal Server Error";
        case 503: return "Service Unavailable";
        default: return "OK";
    }
}

std::string response_bytes(const HttpResponse& response) {
    std::ostringstream out;
    out << "HTTP/1.1 " << response.status << ' ' << status_text(response.status) << "\r\n"
        << "Content-Type: " << response.type << "\r\n"
        << "Content-Length: " << response.body.size() << "\r\n"
        << "Connection: close\r\n"
        << "Access-Control-Allow-Origin: *\r\n"
        << "Access-Control-Allow-Headers: Content-Type, X-EXOTIC-Actor, X-EXOTIC-Role\r\n"
        << "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
        << "Cache-Control: no-store\r\n";
    for (const auto& [key, value] : response.headers) out << key << ": " << value << "\r\n";
    out << "\r\n" << response.body;
    return out.str();
}

bool send_all(Socket socket, std::string_view data) {
    std::size_t sent = 0;
    while (sent < data.size()) {
#ifdef _WIN32
        const int count = send(socket, data.data() + sent, static_cast<int>(data.size() - sent), 0);
#else
        const auto count = send(socket, data.data() + sent, data.size() - sent, 0);
#endif
        if (count <= 0) return false;
        sent += static_cast<std::size_t>(count);
    }
    return true;
}

std::optional<HttpRequest> read_request(Socket socket) {
    constexpr std::size_t kMaximumRequest = 1024 * 1024;
    std::string input;
    std::array<char, 8192> buffer{};
    std::size_t header_end = std::string::npos;
    std::size_t content_length = 0;

    while (input.size() < kMaximumRequest) {
#ifdef _WIN32
        const int count = recv(socket, buffer.data(), static_cast<int>(buffer.size()), 0);
#else
        const auto count = recv(socket, buffer.data(), buffer.size(), 0);
#endif
        if (count <= 0) break;
        input.append(buffer.data(), static_cast<std::size_t>(count));
        if (header_end == std::string::npos) {
            header_end = input.find("\r\n\r\n");
            if (header_end != std::string::npos) {
                const auto header = input.substr(0, header_end);
                const auto marker = lowercase(header).find("content-length:");
                if (marker != std::string::npos) {
                    auto start = marker + std::string("content-length:").size();
                    auto end = header.find("\r\n", start);
                    try { content_length = std::stoull(trim(header.substr(start, end - start))); }
                    catch (...) { return std::nullopt; }
                }
            }
        }
        if (header_end != std::string::npos && input.size() >= header_end + 4 + content_length) break;
    }

    if (header_end == std::string::npos) return std::nullopt;
    std::istringstream headers{input.substr(0, header_end)};
    HttpRequest request;
    std::string line;
    if (!std::getline(headers, line)) return std::nullopt;
    if (!line.empty() && line.back() == '\r') line.pop_back();
    {
        std::istringstream first{line};
        std::string version;
        first >> request.method >> request.target >> version;
        if (request.method.empty() || request.target.empty()) return std::nullopt;
    }
    while (std::getline(headers, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        const auto separator = line.find(':');
        if (separator == std::string::npos) continue;
        request.headers[lowercase(trim(line.substr(0, separator)))] = trim(line.substr(separator + 1));
    }
    request.body = input.substr(header_end + 4, content_length);
    return request;
}

std::string dimension_label(std::string_view dimension) {
    if (dimension == "money_usd") return "Operating budget";
    if (dimension == "api_credits") return "API credits";
    if (dimension == "cpu_milliseconds") return "CPU time";
    if (dimension == "gpu_milliseconds") return "GPU time";
    if (dimension == "memory_bytes") return "Memory capacity";
    if (dimension == "storage_bytes") return "Persistent storage";
    if (dimension == "network_bytes") return "Network transfer";
    if (dimension == "concurrency_slots") return "Concurrent operations";
    return std::string{dimension};
}

std::string dimension_unit(std::string_view dimension) {
    if (dimension == "money_usd") return "USD";
    if (dimension == "api_credits") return "credits";
    if (dimension == "cpu_milliseconds" || dimension == "gpu_milliseconds") return "hours";
    if (dimension == "memory_bytes" || dimension == "storage_bytes") return "GB";
    if (dimension == "network_bytes") return "GB";
    if (dimension == "concurrency_slots") return "slots";
    return "units";
}

double dimension_scale(std::string_view dimension) {
    if (dimension == "cpu_milliseconds" || dimension == "gpu_milliseconds") return 3600000.0;
    if (dimension == "memory_bytes" || dimension == "storage_bytes" || dimension == "network_bytes") return 1073741824.0;
    return 1.0;
}

class SnapshotBuilder {
public:
    SnapshotBuilder(DatabaseView& database, std::filesystem::path workspace)
        : db_(database), workspace_(std::move(workspace)),
          workspace_id_(discover_workspace_id(db_, workspace_)) {}

    std::string build() {
        const auto service_rows = db_.table_exists("runtime_service_health")
            ? db_.query("SELECT service,state,level,message,observed_at_ms FROM runtime_service_health WHERE workspace_id=" + sql_quote(workspace_id_) + " ORDER BY service;")
            : std::vector<Row>{};
        const auto active_operations = count_where("operations", "status IN ('running','verifying')");
        const auto queued_jobs = count_where("scheduler_jobs", "status IN ('pending','ready','leased','running','waiting_retry','blocked')");
        const auto pending_approvals = count_where("governance_requests", "status='pending'");
        const auto active_agents = count_where("agents", "status='active' AND availability='available' AND health IN ('healthy','degraded')");
        const auto open_alerts = count_where("runtime_alerts", "active=1");
        const bool emergency = emergency_active();
        const int health = service_health(service_rows, emergency);

        std::ostringstream out;
        out << "{";
        out << "\"summary\":{";
        out << "\"workspace\":" << quoted(workspace_.string()) << ',';
        out << "\"version\":\"1.0.0\",";
        out << "\"mode\":" << quoted(mode_from_workspace(workspace_)) << ',';
        out << "\"uptime\":" << quoted(uptime()) << ',';
        out << "\"health\":" << health << ',';
        out << "\"activeOperations\":" << active_operations << ',';
        out << "\"queuedJobs\":" << queued_jobs << ',';
        out << "\"pendingApprovals\":" << pending_approvals << ',';
        out << "\"activeAgents\":" << active_agents << ',';
        out << "\"openAlerts\":" << open_alerts << ',';
        out << "\"emergencyStop\":" << (emergency ? "true" : "false") << ',';
        out << "\"lastSync\":\"just now\"";
        out << "},";
        out << "\"throughput\":" << throughput_json() << ',';
        out << "\"reliability\":" << reliability_json() << ',';
        out << "\"objectives\":" << objectives_json() << ',';
        out << "\"proposals\":" << proposals_json() << ',';
        out << "\"approvals\":" << approvals_json() << ',';
        out << "\"jobs\":" << jobs_json() << ',';
        out << "\"agents\":" << agents_json() << ',';
        out << "\"resources\":" << resources_json() << ',';
        out << "\"operations\":" << operations_json() << ',';
        out << "\"audit\":" << audit_json() << ',';
        out << "\"traces\":" << traces_json() << ',';
        out << "\"alerts\":" << alerts_json() << ',';
        out << "\"services\":" << services_json(service_rows);
        out << "}";
        return out.str();
    }

private:
    DatabaseView& db_;
    std::filesystem::path workspace_;
    std::string workspace_id_;

    std::int64_t count_where(std::string_view table, std::string_view where = {}) const {
        if (!db_.table_exists(table)) return 0;
        std::string sql = "SELECT COUNT(*) FROM " + std::string{table};
        if (!where.empty()) sql += " WHERE " + std::string{where};
        sql += ';';
        return db_.integer(sql);
    }

    bool emergency_active() const {
        const bool governance = db_.table_exists("governance_control") &&
            db_.integer("SELECT emergency_stop FROM governance_control WHERE singleton=1;") != 0;
        const bool resources = db_.table_exists("resource_control") &&
            db_.integer("SELECT emergency_stop FROM resource_control WHERE id=1;") != 0;
        const bool requested = db_.table_exists("runtime_controls") &&
            db_.integer("SELECT COUNT(*) FROM runtime_controls WHERE workspace_id=" + sql_quote(workspace_id_) + " AND key='emergency' AND value='activate';") != 0;
        return governance || resources || requested;
    }

    int service_health(const std::vector<Row>& rows, bool emergency) const {
        if (emergency) return 0;
        if (rows.empty()) return 50;
        double total = 0.0;
        for (const auto& row : rows) {
            const auto level = lowercase(row[2]);
            if (level == "healthy") total += 1.0;
            else if (level == "degraded") total += 0.65;
            else if (level == "unknown") total += 0.25;
        }
        return static_cast<int>(std::round(100.0 * total / static_cast<double>(rows.size())));
    }

    std::string uptime() const {
        if (!db_.table_exists("runtime_audit")) return "not started";
        const auto started = db_.integer(
            "SELECT MIN(created_at_ms) FROM runtime_audit WHERE workspace_id=" +
            sql_quote(workspace_id_) + " AND message LIKE 'Runtime started%';"
        );
        if (started <= 0) return "not started";
        const auto seconds = std::max<std::int64_t>(0, now_ms() - started) / 1000;
        const auto days = seconds / 86400;
        const auto hours = (seconds % 86400) / 3600;
        const auto minutes = (seconds % 3600) / 60;
        std::ostringstream out;
        if (days > 0) out << days << "d ";
        out << hours << "h " << minutes << "m";
        return out.str();
    }

    std::string throughput_json() const {
        std::array<int, 12> counts{};
        if (db_.table_exists("operations")) {
            const auto rows = db_.query("SELECT completed_at_ms FROM operations WHERE completed_at_ms IS NOT NULL AND completed_at_ms>=" + std::to_string(now_ms() - 24LL * 60 * 60 * 1000) + ";");
            for (const auto& row : rows) {
                std::int64_t value = 0;
                try { value = std::stoll(row[0]); } catch (...) { continue; }
                const auto age_hours = std::clamp<std::int64_t>((now_ms() - value) / 3600000, 0, 23);
                const auto bucket = static_cast<std::size_t>(11 - age_hours / 2);
                counts[bucket] += 1;
            }
        }
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < counts.size(); ++index) {
            if (index) out << ',';
            out << "{\"label\":" << quoted(std::to_string(index * 2))
                << ",\"value\":" << counts[index] << '}';
        }
        out << ']';
        return out.str();
    }

    std::string reliability_json() const {
        double reliability = 0.0;
        if (db_.table_exists("operations")) {
            const auto total = db_.integer("SELECT COUNT(*) FROM operations WHERE status IN ('completed','failed');");
            const auto passed = db_.integer("SELECT COUNT(*) FROM operations WHERE verification_passed=1;");
            reliability = total > 0 ? 100.0 * static_cast<double>(passed) / static_cast<double>(total) : 0.0;
        }
        static constexpr std::array<std::string_view, 7> days{"Mon","Tue","Wed","Thu","Fri","Sat","Sun"};
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < days.size(); ++index) {
            if (index) out << ',';
            out << "{\"label\":" << quoted(days[index]) << ",\"value\":" << std::fixed << std::setprecision(1) << reliability << '}';
        }
        out << ']';
        return out.str();
    }

    std::string objectives_json() const {
        if (!db_.table_exists("objectives")) return "[]";
        const auto rows = db_.query("SELECT id,title,desired_outcome,priority,status,created_at_ms FROM objectives ORDER BY id DESC LIMIT 100;");
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < rows.size(); ++index) {
            const auto& row = rows[index];
            const auto ui_status = status_for_ui(row[4]);
            int progress = 20;
            if (ui_status == "completed") progress = 100;
            else if (ui_status == "running") progress = 65;
            else if (ui_status == "warning") progress = 45;
            else if (ui_status == "critical") progress = 100;
            if (index) out << ',';
            out << "{\"id\":" << quoted("OBJ-" + row[0])
                << ",\"title\":" << quoted(row[1])
                << ",\"owner\":\"Runtime\""
                << ",\"priority\":" << quoted(row[3])
                << ",\"progress\":" << progress
                << ",\"status\":" << quoted(ui_status)
                << ",\"updated\":" << quoted(relative_time(parse_i64(row[5])))
                << ",\"outcome\":" << quoted(row[2]) << '}';
        }
        out << ']';
        return out.str();
    }

    std::string proposals_json() const {
        if (!db_.table_exists("proposals")) return "[]";
        const auto rows = db_.query("SELECT id,objective_id,plan_name,proposed_by,risk,confidence,estimated_usd,status,created_at_ms FROM proposals ORDER BY id DESC LIMIT 100;");
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < rows.size(); ++index) {
            const auto& row = rows[index];
            if (index) out << ',';
            out << "{\"id\":" << quoted("PRP-" + row[0])
                << ",\"objectiveId\":" << quoted("OBJ-" + row[1])
                << ",\"title\":" << quoted(row[2])
                << ",\"agent\":" << quoted(row[3].empty() ? "Unassigned" : row[3])
                << ",\"risk\":" << quoted(capitalize(row[4]))
                << ",\"confidence\":" << static_cast<int>(std::round(parse_double(row[5]) * 100.0))
                << ",\"cost\":" << parse_double(row[6])
                << ",\"status\":" << quoted(status_for_ui(row[7]))
                << ",\"created\":" << quoted(relative_time(parse_i64(row[8]))) << '}';
        }
        out << ']';
        return out.str();
    }

    std::string approvals_json() const {
        if (!db_.table_exists("governance_requests")) return "[]";
        const auto rows = db_.query("SELECT id,proposal_id,requester_id,risk,requested_budget,required_approvals,status,expires_at_ms FROM governance_requests ORDER BY id DESC LIMIT 100;");
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < rows.size(); ++index) {
            const auto& row = rows[index];
            const auto request_id = row[0];
            std::vector<std::string> roles;
            std::int64_t approvals = 0;
            if (db_.table_exists("governance_decisions")) {
                const auto decision_rows = db_.query("SELECT approver_role,vote FROM governance_decisions WHERE request_id=" + request_id + " ORDER BY id;");
                for (const auto& decision : decision_rows) {
                    if (!decision[0].empty() && std::find(roles.begin(), roles.end(), decision[0]) == roles.end()) roles.push_back(decision[0]);
                    if (lowercase(decision[1]) == "approve") ++approvals;
                }
            }
            if (roles.empty()) roles.push_back("Authorized approver");
            if (index) out << ',';
            out << "{\"id\":" << quoted("APR-" + request_id)
                << ",\"requestId\":" << request_id
                << ",\"proposal\":" << quoted("PRP-" + row[1] + " · governed execution")
                << ",\"requester\":" << quoted(row[2])
                << ",\"quorum\":" << quoted(std::to_string(approvals) + " / " + row[5])
                << ",\"roles\":[";
            for (std::size_t role = 0; role < roles.size(); ++role) {
                if (role) out << ',';
                out << quoted(roles[role]);
            }
            out << "]"
                << ",\"expires\":" << quoted(expires_in(parse_i64(row[7])))
                << ",\"risk\":" << quoted(capitalize(row[3]))
                << ",\"budget\":" << parse_double(row[4])
                << ",\"status\":" << quoted(status_for_ui(row[6])) << '}';
        }
        out << ']';
        return out.str();
    }

    std::string jobs_json() const {
        if (!db_.table_exists("scheduler_jobs")) return "[]";
        const auto rows = db_.query("SELECT j.id,j.name,j.trigger_kind,j.interval_ms,j.event_type,j.condition_expression,j.next_run_at_ms,j.priority,COALESCE(l.worker_id,''),j.attempt,j.status FROM scheduler_jobs j LEFT JOIN scheduler_leases l ON l.job_id=j.id AND l.released=0 ORDER BY j.priority DESC,j.id DESC LIMIT 100;");
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < rows.size(); ++index) {
            const auto& row = rows[index];
            std::string trigger = row[2];
            if (row[2] == "fixed_interval") trigger = "Every " + std::to_string(std::max<std::int64_t>(1, parse_i64(row[3]) / 1000)) + " seconds";
            else if (row[2] == "event_match") trigger = "Event: " + row[4];
            else if (row[2] == "condition") trigger = "Condition: " + row[5];
            else if (row[2] == "at_time") trigger = "Scheduled time";
            const auto delta = parse_i64(row[6]) - now_ms();
            const auto next = delta <= 0 ? "due" : (delta < 60000 ? std::to_string(delta / 1000) + "s" : std::to_string(delta / 60000) + "m");
            if (index) out << ',';
            out << "{\"id\":" << quoted("JOB-" + row[0])
                << ",\"name\":" << quoted(row[1])
                << ",\"trigger\":" << quoted(trigger)
                << ",\"nextRun\":" << quoted(next)
                << ",\"priority\":" << parse_i64(row[7])
                << ",\"worker\":" << quoted(row[8].empty() ? "unassigned" : row[8])
                << ",\"attempts\":" << parse_i64(row[9])
                << ",\"status\":" << quoted(status_for_ui(row[10])) << '}';
        }
        out << ']';
        return out.str();
    }

    std::string agents_json() const {
        if (!db_.table_exists("agents")) return "[]";
        const auto rows = db_.query("SELECT id,display_name,specialist_title,model_name,trust,active_tasks,maximum_tasks,utilization,hourly_cost_usd,status,health,last_heartbeat_at_ms FROM agents ORDER BY id DESC LIMIT 100;");
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < rows.size(); ++index) {
            const auto& row = rows[index];
            const auto capabilities = db_.table_exists("agent_capabilities")
                ? db_.query("SELECT capability_key,proficiency,reliability FROM agent_capabilities WHERE agent_id=" + row[0] + " ORDER BY proficiency DESC LIMIT 6;")
                : std::vector<Row>{};
            double reliability = 0.0;
            for (const auto& capability : capabilities) reliability = std::max(reliability, parse_double(capability[2]));
            if (index) out << ',';
            out << "{\"id\":" << quoted("AGT-" + row[0])
                << ",\"name\":" << quoted(row[1])
                << ",\"role\":" << quoted(row[2].empty() ? "Specialist" : row[2])
                << ",\"model\":" << quoted(row[3].empty() ? "runtime" : row[3])
                << ",\"trust\":" << trust_percent(row[4])
                << ",\"reliability\":" << static_cast<int>(std::round(reliability * 100.0))
                << ",\"load\":" << static_cast<int>(std::round(parse_double(row[7]) * 100.0))
                << ",\"cost\":" << quoted("$" + format_number(parse_double(row[8]), 2) + "/h")
                << ",\"capabilities\":[";
            for (std::size_t capability = 0; capability < capabilities.size(); ++capability) {
                if (capability) out << ',';
                out << quoted(capabilities[capability][0]);
            }
            out << "]"
                << ",\"status\":" << quoted(agent_ui_status(row[9], row[10]))
                << ",\"lastHeartbeat\":" << quoted(relative_time(parse_i64(row[11]))) << '}';
        }
        out << ']';
        return out.str();
    }

    std::string resources_json() const {
        if (!db_.table_exists("resource_account_limits")) return "[]";
        std::string account_filter;
        if (db_.table_exists("resource_accounts")) {
            const auto account = db_.query("SELECT id FROM resource_accounts WHERE scope='workspace' ORDER BY id LIMIT 1;");
            if (!account.empty()) account_filter = " WHERE account_id=" + account.front()[0];
        }
        const auto rows = db_.query("SELECT dimension,hard_limit,spent,reserved FROM resource_account_limits" + account_filter + " ORDER BY dimension;");
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < rows.size(); ++index) {
            const auto& row = rows[index];
            const auto scale = dimension_scale(row[0]);
            const double limit = std::max(0.0001, parse_double(row[1]) / scale);
            const double used = std::max(0.0, (parse_double(row[2]) + parse_double(row[3])) / scale);
            const double forecast = std::min(limit, used * 1.15);
            const double utilization = 100.0 * used / limit;
            const auto status = utilization >= 95.0 ? "critical" : utilization >= 75.0 ? "warning" : "healthy";
            if (index) out << ',';
            out << "{\"name\":" << quoted(dimension_label(row[0]))
                << ",\"used\":" << format_number(used, 2)
                << ",\"limit\":" << format_number(limit, 2)
                << ",\"unit\":" << quoted(dimension_unit(row[0]))
                << ",\"forecast\":" << format_number(forecast, 2)
                << ",\"status\":" << quoted(status) << '}';
        }
        out << ']';
        return out.str();
    }

    std::string operations_json() const {
        std::vector<Row> rows;
        if (db_.table_exists("operations")) {
            rows = db_.query("SELECT o.id,COALESCE(obj.title,'Objective '||o.objective_id),o.agent_id,o.started_at_ms,o.completed_at_ms,o.verification_confidence,o.status FROM operations o LEFT JOIN objectives obj ON obj.id=o.objective_id ORDER BY o.id DESC LIMIT 100;");
        }
        std::ostringstream out;
        out << '[';
        if (rows.empty()) {
            out << "{\"id\":\"OP-0\",\"objective\":\"No live operations yet\",\"agent\":\"unassigned\",\"started\":\"not started\",\"duration\":\"00:00\",\"verification\":0,\"traceId\":\"TR-NONE\",\"status\":\"pending\"}";
        } else {
            for (std::size_t index = 0; index < rows.size(); ++index) {
                const auto& row = rows[index];
                const auto started = parse_i64(row[3]);
                const auto completed = parse_i64(row[4]);
                if (index) out << ',';
                out << "{\"id\":" << quoted("OP-" + row[0])
                    << ",\"objective\":" << quoted(row[1])
                    << ",\"agent\":" << quoted(row[2].empty() ? "unassigned" : row[2])
                    << ",\"started\":" << quoted(relative_time(started))
                    << ",\"duration\":" << quoted(format_duration(started, completed))
                    << ",\"verification\":" << static_cast<int>(std::round(parse_double(row[5]) * 100.0))
                    << ",\"traceId\":" << quoted("TR-OP-" + row[0])
                    << ",\"status\":" << quoted(status_for_ui(row[6])) << '}';
            }
        }
        out << ']';
        return out.str();
    }

    std::string audit_json() const {
        struct AuditItem { std::string id,time,actor,event,entity,message,accent; std::int64_t at{}; };
        std::vector<AuditItem> items;
        if (db_.table_exists("runtime_audit")) {
            for (const auto& row : db_.query("SELECT id,created_at_ms,actor,category,entity_type||':'||entity_id,message FROM runtime_audit WHERE workspace_id=" + sql_quote(workspace_id_) + " ORDER BY id DESC LIMIT 80;")) {
                items.push_back({"AUD-"+row[0],time_of_day(parse_i64(row[1])),row[2],row[3],row[4],row[5],accent_for(row[3]),parse_i64(row[1])});
            }
        }
        if (db_.table_exists("audit_events")) {
            for (const auto& row : db_.query("SELECT id,created_at_ms,actor,event_type,entity_type||':'||entity_id,message FROM audit_events ORDER BY id DESC LIMIT 80;")) {
                items.push_back({"AUT-"+row[0],time_of_day(parse_i64(row[1])),row[2],row[3],row[4],row[5],accent_for(row[3]),parse_i64(row[1])});
            }
        }
        if (db_.table_exists("resource_ledger_events")) {
            for (const auto& row : db_.query("SELECT id,created_at_ms,actor,event_type,entity_type||':'||entity_id,payload FROM resource_ledger_events ORDER BY id DESC LIMIT 40;")) {
                items.push_back({"RES-"+row[0],time_of_day(parse_i64(row[1])),row[2],row[3],row[4],row[5],accent_for(row[3]),parse_i64(row[1])});
            }
        }
        std::sort(items.begin(), items.end(), [](const auto& left, const auto& right){ return left.at > right.at; });
        if (items.size() > 100) items.resize(100);
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < items.size(); ++index) {
            const auto& item = items[index];
            if (index) out << ',';
            out << "{\"id\":" << quoted(item.id)
                << ",\"time\":" << quoted(item.time)
                << ",\"actor\":" << quoted(item.actor)
                << ",\"event\":" << quoted(item.event)
                << ",\"entity\":" << quoted(item.entity)
                << ",\"message\":" << quoted(item.message)
                << ",\"accent\":" << quoted(item.accent) << '}';
        }
        out << ']';
        return out.str();
    }

    std::string traces_json() const {
        if (!db_.table_exists("runtime_traces")) return "[]";
        const auto rows = db_.query("SELECT span_id,service,operation,started_at_ms,COALESCE(ended_at_ms,0),status FROM runtime_traces WHERE workspace_id=" + sql_quote(workspace_id_) + " ORDER BY started_at_ms DESC LIMIT 40;");
        std::ostringstream out;
        out << '[';
        std::int64_t minimum = now_ms();
        std::int64_t maximum = 0;
        for (const auto& row : rows) {
            minimum = std::min(minimum, parse_i64(row[3]));
            maximum = std::max(maximum, parse_i64(row[4]) > 0 ? parse_i64(row[4]) : now_ms());
        }
        const auto range = std::max<std::int64_t>(1, maximum - minimum);
        for (std::size_t index = 0; index < rows.size(); ++index) {
            const auto& row = rows[index];
            const auto start_ms = parse_i64(row[3]);
            const auto end_ms = parse_i64(row[4]) > 0 ? parse_i64(row[4]) : now_ms();
            const int start = static_cast<int>(100.0 * static_cast<double>(start_ms - minimum) / static_cast<double>(range));
            const int duration = std::max(2, static_cast<int>(100.0 * static_cast<double>(end_ms - start_ms) / static_cast<double>(range)));
            if (index) out << ',';
            out << "{\"id\":" << quoted(row[0])
                << ",\"service\":" << quoted(row[1])
                << ",\"operation\":" << quoted(row[2])
                << ",\"start\":" << std::clamp(start, 0, 98)
                << ",\"duration\":" << std::clamp(duration, 2, 100)
                << ",\"status\":" << quoted(status_for_ui(row[5])) << '}';
        }
        out << ']';
        return out.str();
    }

    std::string alerts_json() const {
        if (!db_.table_exists("runtime_alerts")) return "[]";
        const auto rows = db_.query("SELECT id,severity,source,code,message,details_json,active,created_at_ms,acknowledged_at_ms FROM runtime_alerts WHERE workspace_id=" + sql_quote(workspace_id_) + " ORDER BY id DESC LIMIT 100;");
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < rows.size(); ++index) {
            const auto& row = rows[index];
            if (index) out << ',';
            out << "{\"id\":" << quoted("ALT-" + row[0])
                << ",\"alertId\":" << row[0]
                << ",\"severity\":" << quoted(lowercase(row[1]))
                << ",\"title\":" << quoted(row[4].empty() ? row[3] : row[4])
                << ",\"source\":" << quoted(row[2])
                << ",\"time\":" << quoted(relative_time(parse_i64(row[7])))
                << ",\"acknowledged\":" << ((!row[8].empty() || row[6] == "0") ? "true" : "false")
                << ",\"detail\":" << quoted(row[5].empty() ? row[4] : row[5]) << '}';
        }
        out << ']';
        return out.str();
    }

    std::string services_json(const std::vector<Row>& rows) const {
        std::ostringstream out;
        out << '[';
        for (std::size_t index = 0; index < rows.size(); ++index) {
            const auto& row = rows[index];
            const auto status = lowercase(row[2]) == "healthy" ? "healthy" : lowercase(row[2]) == "degraded" ? "warning" : "critical";
            if (index) out << ',';
            out << "{\"name\":" << quoted(row[0])
                << ",\"version\":\"1.0\""
                << ",\"status\":" << quoted(status)
                << ",\"latency\":0"
                << ",\"heartbeat\":" << quoted(relative_time(parse_i64(row[4])))
                << ",\"message\":" << quoted(row[3]) << '}';
        }
        if (rows.empty()) {
            out << "{\"name\":\"continuous-runtime\",\"version\":\"1.0\",\"status\":\"warning\",\"latency\":0,\"heartbeat\":\"unknown\",\"message\":\"Runtime health has not been published yet.\"}";
        }
        out << ']';
        return out.str();
    }

    static std::int64_t parse_i64(const std::string& value) {
        try { return value.empty() ? 0 : std::stoll(value); }
        catch (...) { return 0; }
    }

    static double parse_double(const std::string& value) {
        try { return value.empty() ? 0.0 : std::stod(value); }
        catch (...) { return 0.0; }
    }

    static std::string format_number(double value, int precision) {
        std::ostringstream out;
        out << std::fixed << std::setprecision(precision) << value;
        return out.str();
    }

    static std::string capitalize(std::string value) {
        if (!value.empty()) value.front() = static_cast<char>(std::toupper(static_cast<unsigned char>(value.front())));
        return value;
    }

    static int trust_percent(std::string_view value) {
        if (value == "critical") return 100;
        if (value == "elevated") return 90;
        if (value == "standard") return 75;
        if (value == "restricted") return 55;
        return 25;
    }

    static std::string agent_ui_status(std::string_view status, std::string_view health) {
        if (status == "revoked" || status == "offline") return "critical";
        if (health == "unhealthy") return "critical";
        if (health == "degraded" || status == "draining") return "warning";
        if (status == "active") return "healthy";
        return "pending";
    }
};

std::string message_json(bool ok, std::string_view message) {
    return std::string{"{\"ok\":"} + (ok ? "true" : "false") + ",\"message\":" + quoted(message) + "}";
}

#ifdef _WIN32
std::wstring widen(const std::filesystem::path& path) { return path.wstring(); }

bool run_process_wait(
    const std::filesystem::path& executable,
    const std::filesystem::path& workspace,
    std::string& message
) {
    if (!std::filesystem::exists(executable)) {
        message = "Simulation executable not found: " + executable.string();
        return false;
    }
    std::wstring command = L"\"" + widen(executable) + L"\" --workspace \"" + widen(workspace) + L"\"";
    std::vector<wchar_t> buffer(command.begin(), command.end());
    buffer.push_back(L'\0');
    STARTUPINFOW startup{};
    startup.cb = sizeof(startup);
    PROCESS_INFORMATION process{};
    if (!CreateProcessW(nullptr, buffer.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &startup, &process)) {
        message = "CreateProcess failed with error " + std::to_string(GetLastError());
        return false;
    }
    WaitForSingleObject(process.hProcess, INFINITE);
    DWORD exit_code = 1;
    GetExitCodeProcess(process.hProcess, &exit_code);
    CloseHandle(process.hThread);
    CloseHandle(process.hProcess);
    message = exit_code == 0 ? "Live simulation completed and verified." : "Simulation executable returned " + std::to_string(exit_code);
    return exit_code == 0;
}
#else
bool run_process_wait(const std::filesystem::path& executable, const std::filesystem::path& workspace, std::string& message) {
    if (!std::filesystem::exists(executable)) {
        message = "Simulation executable not found: " + executable.string();
        return false;
    }
    const std::string command = "\"" + executable.string() + "\" --workspace \"" + workspace.string() + "\"";
    const int result = std::system(command.c_str());
    message = result == 0 ? "Live simulation completed and verified." : "Simulation executable failed.";
    return result == 0;
}
#endif

class RequestHandler {
public:
    explicit RequestHandler(const ServerOptions& options)
        : options_(options), context_(options.workspace), database_path_(context_.paths().runtime_database) {}

    HttpResponse handle(const HttpRequest& request) {
        try {
            if (request.method == "OPTIONS") return {204, "text/plain", {}};
            const auto target = request.target.substr(0, request.target.find('?'));
            if (request.method == "GET" && target == "/api/v1/health") return health();
            if (request.method == "GET" && target == "/api/v1/console/snapshot") return snapshot();
            if (request.method == "POST" && target.rfind("/api/v1/actions/", 0) == 0) {
                return action(target.substr(std::string("/api/v1/actions/").size()), request);
            }
            if (request.method == "GET") return static_file(target);
            return {405, "application/json; charset=utf-8", message_json(false, "Method not allowed")};
        } catch (const std::exception& error) {
            return {500, "application/json; charset=utf-8", message_json(false, error.what())};
        }
    }

private:
    ServerOptions options_;
    exotic::runtime::WorkspaceContext context_;
    std::filesystem::path database_path_;

    HttpResponse health() {
        DatabaseView database{database_path_};
        const auto workspace_id = discover_workspace_id(database, options_.workspace);
        const bool runtime_tables = database.table_exists("runtime_service_health");
        const auto services = runtime_tables ? database.integer(
            "SELECT COUNT(*) FROM runtime_service_health WHERE workspace_id=" +
            sql_quote(workspace_id) + ";"
        ) : 0;
        const bool database_ready = database.table_exists("objectives") &&
            database.table_exists("scheduler_jobs") && database.table_exists("agents");
        std::ostringstream body;
        body << "{\"ok\":" << (database_ready ? "true" : "false")
            << ",\"runtime\":\"EXOTIC Continuous Operations\""
            << ",\"version\":\"1.0.0\""
            << ",\"workspace\":" << quoted(options_.workspace.string())
            << ",\"workspaceId\":" << quoted(workspace_id)
            << ",\"database\":" << quoted(database_path_.string())
            << ",\"services\":" << services << '}';
        return {database_ready ? 200 : 503, "application/json; charset=utf-8", body.str()};
    }

    HttpResponse snapshot() {
        DatabaseView database{database_path_};
        return {200, "application/json; charset=utf-8", SnapshotBuilder{database, options_.workspace}.build()};
    }

    HttpResponse action(std::string action_name, const HttpRequest& request) {
        const auto actor = json_string(request.body, "actor").value_or(
            request.headers.contains("x-exotic-actor") ? request.headers.at("x-exotic-actor") : "console.operator"
        );
        const auto role = json_string(request.body, "role").value_or(
            request.headers.contains("x-exotic-role") ? request.headers.at("x-exotic-role") : "operator"
        );
        const auto reason = json_string(request.body, "reason").value_or("EXOTIC Operations Console action");

        if (action_name == "approval.approve" || action_name == "approval.reject") {
            const auto request_id = json_u64(request.body, "requestId");
            if (!request_id) return {400, "application/json; charset=utf-8", message_json(false, "requestId is required")};
            exotic::autonomy::governance::SqliteGovernanceRepository repository{database_path_};
            exotic::autonomy::governance::GovernanceService service{repository};
            exotic::autonomy::governance::Subject subject;
            subject.id = actor;
            subject.roles = {role};
            const auto vote = action_name == "approval.approve"
                ? exotic::autonomy::governance::Vote::Approve
                : exotic::autonomy::governance::Vote::Reject;
            const auto result = service.decide(*request_id, subject, vote, reason);
            return {200, "application/json; charset=utf-8", message_json(true, "Approval request is now " + exotic::autonomy::governance::to_string(result))};
        }

        DatabaseView workspace_database{database_path_};
        const auto workspace_id = discover_workspace_id(workspace_database, options_.workspace);
        exotic::runtime::SqliteTelemetryRepository telemetry{database_path_, workspace_id};
        exotic::runtime::ControlPlane controls{telemetry, workspace_id};

        if (action_name == "emergency.activate") {
            controls.request_emergency_stop(actor, reason);
            return {202, "application/json; charset=utf-8", message_json(true, "Emergency stop queued for the runtime")};
        }
        if (action_name == "emergency.clear") {
            controls.request_emergency_clear(actor, reason);
            return {202, "application/json; charset=utf-8", message_json(true, "Emergency clear queued for the runtime")};
        }
        if (action_name == "runtime.shutdown") {
            controls.request_shutdown(actor, reason);
            return {202, "application/json; charset=utf-8", message_json(true, "Controlled shutdown queued")};
        }
        if (action_name == "alert.acknowledge") {
            const auto alert_id = json_u64(request.body, "alertId");
            if (!alert_id) return {400, "application/json; charset=utf-8", message_json(false, "alertId is required")};
            DatabaseView database{database_path_};
            if (!database.table_exists("runtime_alerts")) return {404, "application/json; charset=utf-8", message_json(false, "Alert repository is unavailable")};
            database.execute(
                "UPDATE runtime_alerts SET active=0,acknowledged_at_ms=" + std::to_string(now_ms()) +
                " WHERE id=" + std::to_string(*alert_id) +
                " AND workspace_id=" + sql_quote(workspace_id) + ";"
            );
            return {200, "application/json; charset=utf-8", message_json(true, "Alert acknowledged")};
        }
        if (action_name == "simulation.run") {
            if (std::filesystem::exists(context_.paths().lock_directory)) {
                return {
                    409,
                    "application/json; charset=utf-8",
                    message_json(
                        false,
                        "The live runtime currently owns this workspace. Stop the EXOTIC service before starting an isolated simulation."
                    )
                };
            }
            auto executable = options_.smoke_executable;
            if (executable.empty()) {
#ifdef _WIN32
                executable = options_.workspace / "out" / "build" / "console-v1.1" / "Release" / "exotic-runtime-smoke.exe";
#else
                executable = options_.workspace / "out" / "build" / "console-v1.1" / "exotic-runtime-smoke";
#endif
            }
            std::string message;
            const bool ok = run_process_wait(executable, options_.workspace, message);
            return {ok ? 200 : 500, "application/json; charset=utf-8", message_json(ok, message)};
        }
        return {404, "application/json; charset=utf-8", message_json(false, "Unknown action")};
    }

    HttpResponse static_file(std::string target) {
        if (target == "/") target = "/index.html";
        if (target.find("..") != std::string::npos) return {400, "text/plain", "Invalid path"};
        while (!target.empty() && target.front() == '/') target.erase(target.begin());
        const auto path = options_.assets_directory / target;
        if (!std::filesystem::exists(path) || !std::filesystem::is_regular_file(path)) {
            return {404, "text/plain; charset=utf-8", "Not found"};
        }
        return {200, content_type(path), read_file(path)};
    }
};

} // namespace

ApiServer::ApiServer(ServerOptions options) : options_(std::move(options)) {
    options_.workspace = std::filesystem::absolute(options_.workspace);
    options_.assets_directory = std::filesystem::absolute(options_.assets_directory);
}

ApiServer::~ApiServer() = default;

void ApiServer::request_stop() noexcept {
    stop_requested_.store(true);
}

int ApiServer::run() {
#ifdef _WIN32
    WSADATA data{};
    if (WSAStartup(MAKEWORD(2, 2), &data) != 0) {
        throw std::runtime_error("WSAStartup failed");
    }
#endif

    Socket listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listener == kInvalidSocket) {
#ifdef _WIN32
        WSACleanup();
#endif
        throw std::runtime_error("Unable to create local HTTP socket");
    }

    int reuse = 1;
#ifdef _WIN32
    setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char*>(&reuse), sizeof(reuse));
#else
    setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
#endif

    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_port = htons(options_.port);
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(listener, reinterpret_cast<sockaddr*>(&address), sizeof(address)) != 0) {
        close_socket(listener);
#ifdef _WIN32
        WSACleanup();
#endif
        throw std::runtime_error("Unable to bind 127.0.0.1:" + std::to_string(options_.port));
    }
    if (listen(listener, 32) != 0) {
        close_socket(listener);
#ifdef _WIN32
        WSACleanup();
#endif
        throw std::runtime_error("Unable to listen on console API port");
    }

    g_server = this;
    std::signal(SIGINT, signal_handler);
    std::signal(SIGTERM, signal_handler);
    std::cout << "EXOTIC Operations Console API 1.1\n"
              << "workspace=" << options_.workspace.string() << '\n'
              << "database=" << (options_.workspace / ".exotic" / "state" / "continuous-operations.db").string() << '\n'
              << "console=http://127.0.0.1:" << options_.port << "/\n";

    RequestHandler handler{options_};
    while (!stop_requested_.load()) {
        fd_set set;
        FD_ZERO(&set);
        FD_SET(listener, &set);
        timeval timeout{};
        timeout.tv_sec = 0;
        timeout.tv_usec = 250000;
#ifdef _WIN32
        const int ready = select(0, &set, nullptr, nullptr, &timeout);
#else
        const int ready = select(listener + 1, &set, nullptr, nullptr, &timeout);
#endif
        if (ready <= 0) continue;
        sockaddr_in client_address{};
#ifdef _WIN32
        int length = sizeof(client_address);
#else
        socklen_t length = sizeof(client_address);
#endif
        Socket client = accept(listener, reinterpret_cast<sockaddr*>(&client_address), &length);
        if (client == kInvalidSocket) continue;
        if (const auto request = read_request(client)) {
            const auto response = response_bytes(handler.handle(*request));
            send_all(client, response);
        } else {
            send_all(client, response_bytes({400, "application/json; charset=utf-8", message_json(false, "Invalid HTTP request")}));
        }
        close_socket(client);
    }

    g_server = nullptr;
    close_socket(listener);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}

} // namespace exotic::operations_console
