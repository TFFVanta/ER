#pragma once

#include <atomic>
#include <cstdint>
#include <filesystem>
#include <string>

namespace exotic::operations_console {

struct ServerOptions {
    std::filesystem::path workspace;
    std::filesystem::path assets_directory;
    std::filesystem::path smoke_executable;
    std::uint16_t port{8787};
};

class ApiServer {
public:
    explicit ApiServer(ServerOptions options);
    ~ApiServer();

    ApiServer(const ApiServer&) = delete;
    ApiServer& operator=(const ApiServer&) = delete;

    int run();
    void request_stop() noexcept;

private:
    ServerOptions options_;
    std::atomic_bool stop_requested_{false};
};

} // namespace exotic::operations_console
