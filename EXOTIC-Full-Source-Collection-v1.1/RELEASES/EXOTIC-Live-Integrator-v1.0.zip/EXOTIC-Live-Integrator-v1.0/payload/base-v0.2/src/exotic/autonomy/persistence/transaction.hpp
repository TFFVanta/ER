#pragma once

#include "database.hpp"

namespace exotic::autonomy::persistence {

class Transaction {
public:
    explicit Transaction(Database& database);
    ~Transaction();

    Transaction(const Transaction&) = delete;
    Transaction& operator=(const Transaction&) = delete;

    void commit();
    void rollback();

private:
    Database* database_{nullptr};
    bool active_{false};
};

} // namespace exotic::autonomy::persistence
