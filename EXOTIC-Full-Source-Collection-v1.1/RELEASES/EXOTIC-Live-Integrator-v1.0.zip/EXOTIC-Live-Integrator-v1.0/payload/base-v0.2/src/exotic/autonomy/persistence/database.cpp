#include "database.hpp"

#include <sqlite3.h>

#include <utility>

namespace exotic::autonomy::persistence {

namespace {

std::string sqlite_error(sqlite3* database, std::string_view context) {
    std::string message{context};
    message += ": ";

    if (database != nullptr) {
        message += sqlite3_errmsg(database);
    } else {
        message += "unknown SQLite error";
    }

    return message;
}

} // namespace

Database::Database(const std::filesystem::path& path) {
    const auto path_string = path.string();

    const int result = sqlite3_open_v2(
        path_string.c_str(),
        &handle_,
        SQLITE_OPEN_READWRITE |
            SQLITE_OPEN_CREATE |
            SQLITE_OPEN_FULLMUTEX,
        nullptr
    );

    if (result != SQLITE_OK) {
        const auto message = sqlite_error(
            handle_,
            "Failed to open autonomy database"
        );

        if (handle_ != nullptr) {
            sqlite3_close(handle_);
            handle_ = nullptr;
        }

        throw DatabaseError(message);
    }

    configure();
}

Database::~Database() {
    if (handle_ != nullptr) {
        sqlite3_close(handle_);
    }
}

Database::Database(Database&& other) noexcept
    : handle_(std::exchange(other.handle_, nullptr)) {}

Database& Database::operator=(Database&& other) noexcept {
    if (this == &other) {
        return *this;
    }

    if (handle_ != nullptr) {
        sqlite3_close(handle_);
    }

    handle_ = std::exchange(other.handle_, nullptr);
    return *this;
}

void Database::configure() {
    execute("PRAGMA foreign_keys = ON;");
    execute("PRAGMA journal_mode = WAL;");
    execute("PRAGMA synchronous = FULL;");
    execute("PRAGMA busy_timeout = 5000;");
}

void Database::execute(std::string_view sql) {
    char* error_message = nullptr;

    const std::string owned_sql{sql};

    const int result = sqlite3_exec(
        handle_,
        owned_sql.c_str(),
        nullptr,
        nullptr,
        &error_message
    );

    if (result != SQLITE_OK) {
        std::string message = "SQLite execution failed";

        if (error_message != nullptr) {
            message += ": ";
            message += error_message;
            sqlite3_free(error_message);
        }

        throw DatabaseError(message);
    }
}

sqlite3* Database::native_handle() const noexcept {
    return handle_;
}

std::int64_t Database::last_insert_row_id() const noexcept {
    return sqlite3_last_insert_rowid(handle_);
}

Statement::Statement(
    Database& database,
    std::string_view sql
) {
    const std::string owned_sql{sql};

    const int result = sqlite3_prepare_v2(
        database.native_handle(),
        owned_sql.c_str(),
        -1,
        &statement_,
        nullptr
    );

    if (result != SQLITE_OK) {
        throw DatabaseError(
            sqlite_error(
                database.native_handle(),
                "Failed to prepare SQLite statement"
            )
        );
    }
}

Statement::~Statement() {
    if (statement_ != nullptr) {
        sqlite3_finalize(statement_);
    }
}

void Statement::bind(std::size_t index, std::int64_t value) {
    if (sqlite3_bind_int64(statement_, static_cast<int>(index), value) != SQLITE_OK) {
        throw DatabaseError("Failed to bind integer value");
    }
}

void Statement::bind(std::size_t index, double value) {
    if (sqlite3_bind_double(statement_, static_cast<int>(index), value) != SQLITE_OK) {
        throw DatabaseError("Failed to bind double value");
    }
}

void Statement::bind(std::size_t index, std::string_view value) {
    if (sqlite3_bind_text(statement_, static_cast<int>(index), value.data(), static_cast<int>(value.size()), SQLITE_TRANSIENT) != SQLITE_OK) {
        throw DatabaseError("Failed to bind text value");
    }
}

void Statement::bind_null(std::size_t index) {
    if (sqlite3_bind_null(statement_, static_cast<int>(index)) != SQLITE_OK) {
        throw DatabaseError("Failed to bind null value");
    }
}

bool Statement::step() {
    const int result = sqlite3_step(statement_);
    if (result == SQLITE_ROW) return true;
    if (result == SQLITE_DONE) return false;
    throw DatabaseError("SQLite statement step failed");
}

void Statement::execute() {
    if (step()) {
        throw DatabaseError("SQLite write statement unexpectedly returned a row");
    }
}

std::int64_t Statement::column_int64(int index) const { return sqlite3_column_int64(statement_, index); }
double Statement::column_double(int index) const { return sqlite3_column_double(statement_, index); }
std::string Statement::column_text(int index) const {
    const auto* value = sqlite3_column_text(statement_, index);
    return value == nullptr ? std::string{} : reinterpret_cast<const char*>(value);
}
bool Statement::column_is_null(int index) const { return sqlite3_column_type(statement_, index) == SQLITE_NULL; }

} // namespace exotic::autonomy::persistence
