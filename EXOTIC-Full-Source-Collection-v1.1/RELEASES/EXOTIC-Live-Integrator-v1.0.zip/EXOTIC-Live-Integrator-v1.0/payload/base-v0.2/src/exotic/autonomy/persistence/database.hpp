#pragma once

#include <filesystem>
#include <stdexcept>
#include <string>
#include <string_view>

struct sqlite3;
struct sqlite3_stmt;

namespace exotic::autonomy::persistence {

class DatabaseError final : public std::runtime_error {
public:
    explicit DatabaseError(const std::string& message)
        : std::runtime_error(message) {}
};

class Database {
public:
    explicit Database(const std::filesystem::path& path);
    ~Database();

    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;

    Database(Database&& other) noexcept;
    Database& operator=(Database&& other) noexcept;

    void execute(std::string_view sql);

    [[nodiscard]]
    sqlite3* native_handle() const noexcept;

    [[nodiscard]]
    std::int64_t last_insert_row_id() const noexcept;

private:
    sqlite3* handle_{nullptr};

    void configure();
};

class Statement {
public:
    Statement(Database& database, std::string_view sql);
    ~Statement();

    Statement(const Statement&) = delete;
    Statement& operator=(const Statement&) = delete;

    void bind(std::size_t index, std::int64_t value);
    void bind(std::size_t index, double value);
    void bind(std::size_t index, std::string_view value);
    void bind_null(std::size_t index);

    [[nodiscard]]
    bool step();

    void execute();

    [[nodiscard]]
    std::int64_t column_int64(int index) const;

    [[nodiscard]]
    double column_double(int index) const;

    [[nodiscard]]
    std::string column_text(int index) const;

    [[nodiscard]]
    bool column_is_null(int index) const;

private:
    sqlite3_stmt* statement_{nullptr};
};

} // namespace exotic::autonomy::persistence
